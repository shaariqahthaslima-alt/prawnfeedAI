from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="farmer")
    full_name = db.Column(db.String(120), default="")
    phone = db.Column(db.String(30), default="")
    farm_name = db.Column(db.String(120), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    ponds = db.relationship("Pond", backref="owner", lazy=True, cascade="all, delete-orphan")
    feed_logs = db.relationship("FeedLog", backref="owner", lazy=True, cascade="all, delete-orphan")
    disease_history = db.relationship("DiseaseHistory", backref="owner", lazy=True, cascade="all, delete-orphan")
    water_quality = db.relationship("WaterQuality", backref="owner", lazy=True, cascade="all, delete-orphan")
    growth_history = db.relationship("GrowthHistory", backref="owner", lazy=True, cascade="all, delete-orphan")
    harvest_records = db.relationship("HarvestRecord", backref="owner", lazy=True, cascade="all, delete-orphan")
    notifications = db.relationship("Notification", backref="owner", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Pond(db.Model):
    __tablename__ = "ponds"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    location = db.Column(db.String(150), default="")
    species = db.Column(db.String(80), default="Prawn")
    stocking_date = db.Column(db.Date, nullable=False)
    seed_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(30), default="Active")
    description = db.Column(db.Text, default="")
    daily_observations = db.Column(db.Text, default="")
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    feed_logs = db.relationship("FeedLog", backref="pond", lazy=True, cascade="all, delete-orphan")
    disease_history = db.relationship("DiseaseHistory", backref="pond", lazy=True, cascade="all, delete-orphan")
    water_quality = db.relationship("WaterQuality", backref="pond", lazy=True, cascade="all, delete-orphan")
    growth_history = db.relationship("GrowthHistory", backref="pond", lazy=True, cascade="all, delete-orphan")
    harvest_records = db.relationship("HarvestRecord", backref="pond", lazy=True, cascade="all, delete-orphan")


class FeedLog(db.Model):
    __tablename__ = "feed_logs"

    id = db.Column(db.Integer, primary_key=True)
    pond_id = db.Column(db.Integer, db.ForeignKey("ponds.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    date = db.Column(db.Date, default=datetime.utcnow)
    biomass_kg = db.Column(db.Float, default=0.0)
    feed_percentage = db.Column(db.Float, default=0.0)
    daily_feed_requirement = db.Column(db.Float, default=0.0)
    feed_per_session = db.Column(db.Float, default=0.0)
    feed_conversion_ratio = db.Column(db.Float, default=0.0)
    feed_cost_per_kg = db.Column(db.Float, default=0.0)
    estimated_feed_cost = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class DiseaseHistory(db.Model):
    __tablename__ = "disease_history"

    id = db.Column(db.Integer, primary_key=True)
    pond_id = db.Column(db.Integer, db.ForeignKey("ponds.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    disease_name = db.Column(db.String(120), nullable=False)
    confidence = db.Column(db.Float, default=0.0)
    severity = db.Column(db.String(30), default="Moderate")
    symptoms = db.Column(db.Text, default="")
    causes = db.Column(db.Text, default="")
    treatment = db.Column(db.Text, default="")
    prevention = db.Column(db.Text, default="")
    biosecurity = db.Column(db.Text, default="")
    image_path = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WaterQuality(db.Model):
    __tablename__ = "water_quality"

    id = db.Column(db.Integer, primary_key=True)
    pond_id = db.Column(db.Integer, db.ForeignKey("ponds.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    temperature = db.Column(db.Float, default=0.0)
    ph = db.Column(db.Float, default=0.0)
    salinity = db.Column(db.Float, default=0.0)
    dissolved_oxygen = db.Column(db.Float, default=0.0)
    ammonia = db.Column(db.Float, default=0.0)
    water_level = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(30), default="Good")
    notes = db.Column(db.Text, default="")
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow)


class GrowthHistory(db.Model):
    __tablename__ = "growth_history"

    id = db.Column(db.Integer, primary_key=True)
    pond_id = db.Column(db.Integer, db.ForeignKey("ponds.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    record_date = db.Column(db.Date, default=datetime.utcnow)
    average_weight_g = db.Column(db.Float, default=0.0)
    survival_rate = db.Column(db.Float, default=0.0)
    biomass_kg = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class HarvestRecord(db.Model):
    __tablename__ = "harvest_records"

    id = db.Column(db.Integer, primary_key=True)
    pond_id = db.Column(db.Integer, db.ForeignKey("ponds.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    harvest_date = db.Column(db.Date, default=datetime.utcnow)
    total_weight_kg = db.Column(db.Float, default=0.0)
    count = db.Column(db.Integer, default=0)
    harvest_value = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(120), nullable=False)
    message = db.Column(db.Text, default="")
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
