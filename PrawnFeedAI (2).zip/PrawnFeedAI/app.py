import os
from flask import Flask, render_template, redirect, url_for, flash, send_from_directory
from flask_login import LoginManager, current_user
from config import Config
from models import db, User
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.feed import feed_bp
from routes.disease import disease_bp
from routes.records import records_bp
from routes.water import water_bp
from routes.reports import reports_bp
from routes.admin import admin_bp


login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message_category = "info"


def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(Config)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(feed_bp)
    app.register_blueprint(disease_bp)
    app.register_blueprint(records_bp)
    app.register_blueprint(water_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(admin_bp)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.context_processor
    def inject_context():
        is_admin = current_user.is_authenticated and current_user.role == "admin"
        return {"is_admin": is_admin}

    @app.route("/")
    def home():
        return render_template("home.html")

    @app.route("/about")
    def about():
        return render_template("about.html")

    @app.route("/contact")
    def contact():
        return render_template("contact.html")

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username="admin").first():
            admin_user = User(
                username="admin",
                email="admin@prawnfeed.ai",
                full_name="System Administrator",
                role="admin",
                farm_name="PrawnFeed AI"
            )
            admin_user.set_password("admin123")
            db.session.add(admin_user)
            db.session.commit()

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
