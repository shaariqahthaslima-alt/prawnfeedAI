if (typeof labels !== 'undefined') {
   const performanceCtx = document.getElementById('performanceChart');
   if (performanceCtx) {
       new Chart(performanceCtx, {
           type: 'line',
           data: {
               labels,
               datasets: [
                   { label: 'Feed (kg)', data: feedSeries, borderColor: '#0f4c81', backgroundColor: 'rgba(15,76,129,0.2)', tension: 0.3 },
                   { label: 'Growth (kg)', data: growthSeries, borderColor: '#2ec4b6', backgroundColor: 'rgba(46,196,182,0.2)', tension: 0.3 }
               ]
           },
           options: { responsive: true, plugins: { legend: { display: true } } }
       });
   }

   const qualityCtx = document.getElementById('qualityChart');
   if (qualityCtx) {
       new Chart(qualityCtx, {
           type: 'doughnut',
           data: {
               labels: statusLabels,
               datasets: [{ data: statusCounts, backgroundColor: ['#2ec4b6', '#0f4c81', '#f4b942', '#ff6b6b'] }]
           },
           options: { responsive: true }
       });
   }
}
