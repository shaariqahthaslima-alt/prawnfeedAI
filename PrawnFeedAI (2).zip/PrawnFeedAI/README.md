# PrawnFeed AI

PrawnFeed AI is a full-stack Flask application for prawn aquaculture farmers. It includes:

- Farmer registration and login
- Dashboard analytics
- Feed calculator with SQLite storage
- AI disease detection (YOLO-based with fallback heuristics)
- Water quality monitoring
- Farm records management
- PDF and Excel reporting
- Administrator controls

## Run

```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000
