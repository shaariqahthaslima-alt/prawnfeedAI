from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Optional
from models import db, Pond, GrowthHistory, HarvestRecord


records_bp = Blueprint("records", __name__)


class PondForm(FlaskForm):
    name = StringField("Pond Name", validators=[DataRequired()])
    location = StringField("Location", validators=[Optional()])
    species = StringField("Species", validators=[Optional()])
    stocking_date = DateField("Stocking Date", validators=[DataRequired()])
    seed_count = IntegerField("Seed Count", validators=[Optional()])
    status = SelectField("Status", choices=[("Active", "Active"), ("Monitoring", "Monitoring"), ("Harvested", "Harvested")], validators=[Optional()])
    description = TextAreaField("Description", validators=[Optional()])
    daily_observations = TextAreaField("Daily Observations", validators=[Optional()])
    submit = SubmitField("Save Pond")


class GrowthForm(FlaskForm):
    pond_id = SelectField("Pond", coerce=int)
    record_date = DateField("Record Date", validators=[DataRequired()])
    average_weight_g = IntegerField("Average Weight (g)", validators=[DataRequired()])
    survival_rate = IntegerField("Survival Rate (%)", validators=[DataRequired()])
    biomass_kg = IntegerField("Biomass (kg)", validators=[Optional()])
    notes = TextAreaField("Notes", validators=[Optional()])
    submit = SubmitField("Save Growth")


class HarvestForm(FlaskForm):
    pond_id = SelectField("Pond", coerce=int)
    harvest_date = DateField("Harvest Date", validators=[DataRequired()])
    total_weight_kg = IntegerField("Total Weight (kg)", validators=[DataRequired()])
    count = IntegerField("Count", validators=[Optional()])
    harvest_value = IntegerField("Harvest Value", validators=[Optional()])
    notes = TextAreaField("Notes", validators=[Optional()])
    submit = SubmitField("Save Harvest")


@records_bp.route("/farm-records", methods=["GET", "POST"])
@login_required
def farm_records():
    pond_form = PondForm()
    growth_form = GrowthForm()
    harvest_form = HarvestForm()
    ponds = Pond.query.filter_by(user_id=current_user.id)

    search = request.args.get("search", "")
    status = request.args.get("status", "")
    if search:
        ponds = ponds.filter(Pond.name.contains(search))
    if status:
        ponds = ponds.filter(Pond.status == status)
    ponds = ponds.order_by(Pond.created_at.desc())

    page = request.args.get("page", 1, type=int)
    pagination = ponds.paginate(page=page, per_page=6, error_out=False)

    pond_form.status.choices = [("Active", "Active"), ("Monitoring", "Monitoring"), ("Harvested", "Harvested")]
    growth_form.pond_id.choices = [(pond.id, pond.name) for pond in Pond.query.filter_by(user_id=current_user.id).all()]
    harvest_form.pond_id.choices = [(pond.id, pond.name) for pond in Pond.query.filter_by(user_id=current_user.id).all()]

    edit_id = request.args.get("edit_id", type=int)
    if edit_id:
        pond = Pond.query.filter_by(id=edit_id, user_id=current_user.id).first_or_404()
        pond_form.name.data = pond.name
        pond_form.location.data = pond.location
        pond_form.species.data = pond.species
        pond_form.stocking_date.data = pond.stocking_date
        pond_form.seed_count.data = pond.seed_count
        pond_form.status.data = pond.status
        pond_form.description.data = pond.description
        pond_form.daily_observations.data = pond.daily_observations

    if request.method == "POST":
        if "submit_pond" in request.form:
            if pond_form.validate_on_submit():
                pond_id = request.form.get("pond_id")
                if pond_id:
                    pond = Pond.query.filter_by(id=pond_id, user_id=current_user.id).first_or_404()
                    pond.name = pond_form.name.data
                    pond.location = pond_form.location.data
                    pond.species = pond_form.species.data
                    pond.stocking_date = pond_form.stocking_date.data
                    pond.seed_count = pond_form.seed_count.data or 0
                    pond.status = pond_form.status.data or "Active"
                    pond.description = pond_form.description.data or ""
                    pond.daily_observations = pond_form.daily_observations.data or ""
                else:
                    pond = Pond(
                        user_id=current_user.id,
                        name=pond_form.name.data,
                        location=pond_form.location.data or "",
                        species=pond_form.species.data or "Prawn",
                        stocking_date=pond_form.stocking_date.data,
                        seed_count=pond_form.seed_count.data or 0,
                        status=pond_form.status.data or "Active",
                        description=pond_form.description.data or "",
                        daily_observations=pond_form.daily_observations.data or "",
                    )
                    db.session.add(pond)
                db.session.commit()
                flash("Pond record saved successfully.", "success")
                return redirect(url_for("records.farm_records"))
        if "submit_growth" in request.form and growth_form.validate_on_submit():
            growth = GrowthHistory(
                pond_id=growth_form.pond_id.data or None,
                user_id=current_user.id,
                record_date=growth_form.record_date.data,
                average_weight_g=growth_form.average_weight_g.data or 0,
                survival_rate=growth_form.survival_rate.data or 0,
                biomass_kg=growth_form.biomass_kg.data or 0,
                notes=growth_form.notes.data or "",
            )
            db.session.add(growth)
            db.session.commit()
            flash("Growth record added.", "success")
            return redirect(url_for("records.farm_records"))
        if "submit_harvest" in request.form and harvest_form.validate_on_submit():
            harvest = HarvestRecord(
                pond_id=harvest_form.pond_id.data or None,
                user_id=current_user.id,
                harvest_date=harvest_form.harvest_date.data,
                total_weight_kg=harvest_form.total_weight_kg.data or 0,
                count=harvest_form.count.data or 0,
                harvest_value=harvest_form.harvest_value.data or 0,
                notes=harvest_form.notes.data or "",
            )
            db.session.add(harvest)
            db.session.commit()
            flash("Harvest record added.", "success")
            return redirect(url_for("records.farm_records"))
        if "delete_pond" in request.form:
            pond = Pond.query.filter_by(id=request.form.get("delete_pond"), user_id=current_user.id).first()
            if pond:
                db.session.delete(pond)
                db.session.commit()
                flash("Pond deleted.", "warning")
            return redirect(url_for("records.farm_records"))

    return render_template(
        "farm_records.html",
        pond_form=pond_form,
        growth_form=growth_form,
        harvest_form=harvest_form,
        pagination=pagination,
        ponds=pagination.items,
        search=search,
        status=status,
        edit_id=edit_id,
    )
