from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import FloatField, SelectField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Optional
from models import db, Pond, WaterQuality


water_bp = Blueprint("water", __name__)


class WaterQualityForm(FlaskForm):
    pond_id = SelectField("Pond", coerce=int)
    temperature = FloatField("Temperature (°C)", validators=[DataRequired()])
    ph = FloatField("pH", validators=[DataRequired()])
    salinity = FloatField("Salinity (ppt)", validators=[DataRequired()])
    dissolved_oxygen = FloatField("Dissolved Oxygen (mg/L)", validators=[DataRequired()])
    ammonia = FloatField("Ammonia (mg/L)", validators=[DataRequired()])
    water_level = FloatField("Water Level (cm)", validators=[DataRequired()])
    notes = TextAreaField("Notes", validators=[Optional()])
    submit = SubmitField("Save Water Reading")


def classify_status(temp, ph, salinity, do, ammonia, water_level):
    if temp < 24 or temp > 32 or ph < 7.0 or ph > 8.5 or salinity < 10 or salinity > 25 or do < 4.0 or ammonia > 0.1 or water_level < 50:
        return "Critical"
    if temp < 26 or temp > 30 or ph < 7.5 or ph > 8.2 or salinity < 12 or salinity > 20 or do < 5.0 or ammonia > 0.05 or water_level < 70:
        return "Warning"
    if temp < 28 or temp > 29 or ph < 7.8 or ph > 8.0 or salinity < 15 or salinity > 18 or do < 6.0 or ammonia > 0.02:
        return "Good"
    return "Excellent"


@water_bp.route("/water-quality", methods=["GET", "POST"])
@login_required
def water_quality():
    form = WaterQualityForm()
    form.pond_id.choices = [(pond.id, pond.name) for pond in Pond.query.filter_by(user_id=current_user.id).all()]

    if form.validate_on_submit():
        status = classify_status(
            form.temperature.data,
            form.ph.data,
            form.salinity.data,
            form.dissolved_oxygen.data,
            form.ammonia.data,
            form.water_level.data,
        )
        record = WaterQuality(
            pond_id=form.pond_id.data or None,
            user_id=current_user.id,
            temperature=form.temperature.data,
            ph=form.ph.data,
            salinity=form.salinity.data,
            dissolved_oxygen=form.dissolved_oxygen.data,
            ammonia=form.ammonia.data,
            water_level=form.water_level.data,
            status=status,
            notes=form.notes.data or "",
            recorded_at=datetime.utcnow(),
        )
        db.session.add(record)
        db.session.commit()
        if status != "Excellent":
            flash(f"Alert: Water quality is {status}.", "warning")
        else:
            flash("Water quality recorded successfully.", "success")
        return redirect(url_for("water.water_quality"))

    records = WaterQuality.query.filter_by(user_id=current_user.id).order_by(WaterQuality.recorded_at.desc()).all()
    return render_template("water_quality.html", form=form, records=records)
