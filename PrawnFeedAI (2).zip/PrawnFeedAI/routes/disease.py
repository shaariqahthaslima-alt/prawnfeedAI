import os
from datetime import datetime
from pathlib import Path
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import SelectField, SubmitField
from werkzeug.utils import secure_filename
from models import db, Pond, DiseaseHistory


disease_bp = Blueprint("disease", __name__)


class DiseaseForm(FlaskForm):
    pond_id = SelectField("Pond", coerce=int)
    image = FileField("Upload Image", validators=[FileRequired(), FileAllowed(["jpg", "jpeg", "png"], "Images only!")])
    submit = SubmitField("Detect Disease")


def classify_disease_from_image(image):
    try:
        from ultralytics import YOLO
        model = YOLO(str(Path(__file__).resolve().parents[1] / "AI" / "best.pt"))
        results = model(image, stream=True, conf=0.45)
        for result in results:
            if result.boxes and len(result.boxes) > 0:
                cls = int(result.boxes[0].cls[0])
                names = model.names
                label = names.get(cls, "Unknown")
                conf = float(result.boxes[0].conf[0])
                return label, conf
    except Exception:
        pass

    pixels = list(image.getdata())
    avg_r = sum(p[0] for p in pixels) / len(pixels)
    avg_g = sum(p[1] for p in pixels) / len(pixels)
    avg_b = sum(p[2] for p in pixels) / len(pixels)
    if avg_r > 160 and avg_g < 100 and avg_b < 100:
        return "White Spot Syndrome", 0.82
    if avg_g > 110 and avg_r < 120:
        return "Black Gill Disease", 0.74
    if avg_b > 140:
        return "Vibrio Infection", 0.69
    if avg_r > 120 and avg_g > 110 and avg_b < 90:
        return "Shell Disease", 0.63
    if avg_g < 70 and avg_r < 70:
        return "Muscle Necrosis", 0.58
    return "Hepatopancreatic Disease", 0.71


def get_disease_profile(name, confidence):
    profiles = {
        "White Spot Syndrome": {
            "severity": "Critical",
            "symptoms": "White lesions, lethargy, and reduced feeding.",
            "causes": "Viral infection favored by poor water quality and stress.",
            "treatment": "Immediate isolation, water quality correction, and veterinary consultation.",
            "prevention": "Use certified seed, strict biosecurity, and stable water parameters.",
            "biosecurity": "Separate infected ponds and disinfect equipment between ponds.",
        },
        "Black Gill Disease": {
            "severity": "High",
            "symptoms": "Darkened gills and abnormal breathing.",
            "causes": "Poor oxygen, high ammonia, and microbial activity.",
            "treatment": "Improve aeration, reduce stress, and apply supportive treatment.",
            "prevention": "Monitor ammonia and oxygen daily.",
            "biosecurity": "Avoid shared nets and maintain sanitation.",
        },
        "Vibrio Infection": {
            "severity": "High",
            "symptoms": "Red discoloration, poor appetite, and mortality spikes.",
            "causes": "Pathogenic Vibrio bacteria under warm, stressed conditions.",
            "treatment": "Use approved antimicrobial protocols and water management.",
            "prevention": "Keep salinity and sanitation consistent.",
            "biosecurity": "Quarantine new stock and disinfect tanks.",
        },
        "Shell Disease": {
            "severity": "Moderate",
            "symptoms": "Shell erosion and discoloration on the carapace.",
            "causes": "Environmental stress and opportunistic microbes.",
            "treatment": "Improve habitat conditions and support shell recovery.",
            "prevention": "Ensure balanced nutrition and water stability.",
            "biosecurity": "Clean equipment and reduce transfer of infected stock.",
        },
        "Muscle Necrosis": {
            "severity": "Severe",
            "symptoms": "Muscle tissue discoloration and weak movement.",
            "causes": "Nutritional imbalance and infection.",
            "treatment": "Adjust feed and consult a specialist.",
            "prevention": "Offer high-quality nutrition and monitor stock closely.",
            "biosecurity": "Limit transfer of shrimp between ponds.",
        },
        "Hepatopancreatic Disease": {
            "severity": "Critical",
            "symptoms": "Reduced feeding, poor growth, and pale hepatopancreas.",
            "causes": "Infectious disease and environmental stress.",
            "treatment": "Rapid intervention, improved water quality, and veterinary care.",
            "prevention": "Maintain strong sanitation and stress reduction.",
            "biosecurity": "Use strict biosecure movement controls.",
        },
    }
    return profiles.get(name, profiles["Hepatopancreatic Disease"])


@disease_bp.route("/disease-detection", methods=["GET", "POST"])
@login_required
def disease_detection():
    form = DiseaseForm()
    form.pond_id.choices = [(pond.id, pond.name) for pond in Pond.query.filter_by(user_id=current_user.id).all()]

    result = None
    if form.validate_on_submit():
        file = form.image.data
        filename = secure_filename(file.filename)
        unique_name = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{filename}"
        save_path = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_name)
        file.save(save_path)

        from PIL import Image
        image = Image.open(save_path).convert("RGB")
        image = image.resize((640, 640))

        try:
            import cv2
            import numpy as np
            gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
            variance = cv2.Laplacian(gray, cv2.CV_64F).var()
            if variance < 60:
                flash("Image quality is too low. Please upload a clearer image.", "warning")
                return render_template("disease_detection.html", form=form, result=None)
        except Exception:
            pass

        disease_name, confidence = classify_disease_from_image(image)
        profile = get_disease_profile(disease_name, confidence)
        result = {
            "disease_name": disease_name,
            "confidence": round(confidence * 100, 1),
            "severity": profile["severity"],
            "symptoms": profile["symptoms"],
            "causes": profile["causes"],
            "treatment": profile["treatment"],
            "prevention": profile["prevention"],
            "biosecurity": profile["biosecurity"],
            "image_path": f"/uploads/{unique_name}",
        }

        record = DiseaseHistory(
            pond_id=form.pond_id.data or None,
            user_id=current_user.id,
            disease_name=result["disease_name"],
            confidence=result["confidence"] / 100.0,
            severity=result["severity"],
            symptoms=result["symptoms"],
            causes=result["causes"],
            treatment=result["treatment"],
            prevention=result["prevention"],
            biosecurity=result["biosecurity"],
            image_path=result["image_path"],
        )
        db.session.add(record)
        db.session.commit()
        flash("Disease analysis completed.", "success")

    return render_template("disease_detection.html", form=form, result=result)
