import io
from flask import Blueprint, render_template, send_file, request
from flask_login import login_required, current_user
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from openpyxl import Workbook
from models import FeedLog, DiseaseHistory, WaterQuality, GrowthHistory, HarvestRecord, Pond


reports_bp = Blueprint("reports", __name__)


@reports_bp.route("/reports")
@login_required
def reports():
    ponds = Pond.query.filter_by(user_id=current_user.id).count()
    feed_logs = FeedLog.query.filter_by(user_id=current_user.id).count()
    disease_logs = DiseaseHistory.query.filter_by(user_id=current_user.id).count()
    water_logs = WaterQuality.query.filter_by(user_id=current_user.id).count()
    harvest_logs = HarvestRecord.query.filter_by(user_id=current_user.id).count()
    return render_template(
        "reports.html",
        ponds=ponds,
        feed_logs=feed_logs,
        disease_logs=disease_logs,
        water_logs=water_logs,
        harvest_logs=harvest_logs,
    )


@reports_bp.route("/reports/export/<report_type>/<format>")
@login_required
def export_report(report_type, format):
    if report_type == "feed":
        rows = FeedLog.query.filter_by(user_id=current_user.id).order_by(FeedLog.date.desc()).all()
        title = "Feed Report"
    elif report_type == "disease":
        rows = DiseaseHistory.query.filter_by(user_id=current_user.id).order_by(DiseaseHistory.created_at.desc()).all()
        title = "Disease Report"
    elif report_type == "water":
        rows = WaterQuality.query.filter_by(user_id=current_user.id).order_by(WaterQuality.recorded_at.desc()).all()
        title = "Water Quality Report"
    elif report_type == "performance":
        rows = GrowthHistory.query.filter_by(user_id=current_user.id).order_by(GrowthHistory.record_date.desc()).all()
        title = "Farm Performance Report"
    elif report_type == "harvest":
        rows = HarvestRecord.query.filter_by(user_id=current_user.id).order_by(HarvestRecord.harvest_date.desc()).all()
        title = "Harvest Report"
    else:
        rows = []
        title = "Report"

    if format == "pdf":
        buffer = io.BytesIO()
        pdf = canvas.Canvas(buffer, pagesize=letter)
        pdf.setTitle(title)
        pdf.setFont("Helvetica-Bold", 16)
        pdf.drawString(40, 770, title)
        pdf.setFont("Helvetica", 10)
        y = 740
        for row in rows[:20]:
            pdf.drawString(40, y, str(row))
            y -= 14
        pdf.save()
        buffer.seek(0)
        return send_file(buffer, as_attachment=True, download_name=f"{report_type}_report.pdf", mimetype="application/pdf")

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = title
    sheet.append(["Date", "Details", "Value"])
    for row in rows[:50]:
        if report_type == "feed":
            sheet.append([str(row.date), row.notes or "", row.daily_feed_requirement])
        elif report_type == "disease":
            sheet.append([str(row.created_at), row.disease_name, row.confidence])
        elif report_type == "water":
            sheet.append([str(row.recorded_at), row.status, row.temperature])
        elif report_type == "performance":
            sheet.append([str(row.record_date), row.notes or "", row.biomass_kg])
        elif report_type == "harvest":
            sheet.append([str(row.harvest_date), row.notes or "", row.total_weight_kg])
    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"{report_type}_report.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
