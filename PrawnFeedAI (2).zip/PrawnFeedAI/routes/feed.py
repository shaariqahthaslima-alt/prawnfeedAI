from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import FloatField, IntegerField, SelectField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Optional
from models import db, Pond, FeedLog


feed_bp = Blueprint("feed", __name__)


class FeedCalculatorForm(FlaskForm):
    pond_id = SelectField("Pond", coerce=int)
    average_weight_g = FloatField("Average Prawn Weight (g)", validators=[DataRequired()])
    number_of_prawns = IntegerField("Number of Prawns", validators=[DataRequired()])
    feed_cost_per_kg = FloatField("Feed Cost Per Kg", validators=[Optional()])
    notes = TextAreaField("Notes", validators=[Optional()])
    submit = SubmitField("Calculate Feed")


@feed_bp.route("/feed-calculator", methods=["GET", "POST"])
@login_required
def feed_calculator():
    form = FeedCalculatorForm()
    form.pond_id.choices = [(pond.id, pond.name) for pond in Pond.query.filter_by(user_id=current_user.id).all()]

    calculated = None
    if form.validate_on_submit():
        average_weight_g = form.average_weight_g.data
        number_of_prawns = form.number_of_prawns.data
        feed_cost = form.feed_cost_per_kg.data or 0.0

        biomass_kg = (average_weight_g * number_of_prawns) / 1000.0
        if average_weight_g <= 6:
            feed_percentage = 3.5
        elif average_weight_g <= 12:
            feed_percentage = 3.0
        elif average_weight_g <= 25:
            feed_percentage = 2.6
        else:
            feed_percentage = 2.0

        daily_feed_requirement = biomass_kg * (feed_percentage / 100.0)
        feed_per_session = daily_feed_requirement / 4.0
        feed_conversion_ratio = round(1.2 + (average_weight_g / 1000.0), 2)
        estimated_feed_cost = daily_feed_requirement * feed_cost if feed_cost else 0.0

        calculated = {
            "biomass_kg": round(biomass_kg, 2),
            "feed_percentage": round(feed_percentage, 2),
            "daily_feed_requirement": round(daily_feed_requirement, 2),
            "feed_per_session": round(feed_per_session, 2),
            "feed_conversion_ratio": feed_conversion_ratio,
            "estimated_feed_cost": round(estimated_feed_cost, 2),
        }

        log = FeedLog(
            pond_id=form.pond_id.data or None,
            user_id=current_user.id,
            date=datetime.utcnow().date(),
            biomass_kg=calculated["biomass_kg"],
            feed_percentage=calculated["feed_percentage"],
            daily_feed_requirement=calculated["daily_feed_requirement"],
            feed_per_session=calculated["feed_per_session"],
            feed_conversion_ratio=calculated["feed_conversion_ratio"],
            feed_cost_per_kg=feed_cost,
            estimated_feed_cost=calculated["estimated_feed_cost"],
            notes=form.notes.data or "",
        )
        db.session.add(log)
        db.session.commit()
        flash("Feed calculation saved successfully.", "success")

    return render_template("feed_calculator.html", form=form, calculated=calculated)
