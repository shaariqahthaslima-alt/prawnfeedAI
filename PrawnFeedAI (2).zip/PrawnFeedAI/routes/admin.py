from flask import Blueprint, render_template, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from models import db, User, Pond, FeedLog, DiseaseHistory, WaterQuality, GrowthHistory, HarvestRecord


admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/admin")
@login_required
def admin_dashboard():
    if current_user.role != "admin":
        abort(403)

    users = User.query.order_by(User.created_at.desc()).all()
    ponds = Pond.query.order_by(Pond.created_at.desc()).all()
    feed_logs = FeedLog.query.order_by(FeedLog.created_at.desc()).all()
    disease_logs = DiseaseHistory.query.order_by(DiseaseHistory.created_at.desc()).all()
    water_logs = WaterQuality.query.order_by(WaterQuality.recorded_at.desc()).all()
    growth_logs = GrowthHistory.query.order_by(GrowthHistory.created_at.desc()).all()
    harvest_logs = HarvestRecord.query.order_by(HarvestRecord.created_at.desc()).all()

    return render_template(
        "admin.html",
        users=users,
        ponds=ponds,
        feed_logs=feed_logs,
        disease_logs=disease_logs,
        water_logs=water_logs,
        growth_logs=growth_logs,
        harvest_logs=harvest_logs,
    )


@admin_bp.route("/admin/delete-user/<int:user_id>")
@login_required
def delete_user(user_id):
    if current_user.role != "admin":
        abort(403)
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete your own admin account.", "warning")
        return redirect(url_for("admin.admin_dashboard"))
    db.session.delete(user)
    db.session.commit()
    flash("Farmer removed successfully.", "success")
    return redirect(url_for("admin.admin_dashboard"))


@admin_bp.route("/admin/delete-record/<record_type>/<int:record_id>")
@login_required
def delete_record(record_type, record_id):
    if current_user.role != "admin":
        abort(403)
    if record_type == "feed":
        record = FeedLog.query.get_or_404(record_id)
    elif record_type == "disease":
        record = DiseaseHistory.query.get_or_404(record_id)
    elif record_type == "water":
        record = WaterQuality.query.get_or_404(record_id)
    elif record_type == "growth":
        record = GrowthHistory.query.get_or_404(record_id)
    elif record_type == "harvest":
        record = HarvestRecord.query.get_or_404(record_id)
    else:
        flash("Unknown record type.", "danger")
        return redirect(url_for("admin.admin_dashboard"))
    db.session.delete(record)
    db.session.commit()
    flash("Record deleted successfully.", "success")
    return redirect(url_for("admin.admin_dashboard"))
