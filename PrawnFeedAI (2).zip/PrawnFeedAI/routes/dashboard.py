from datetime import datetime, timedelta
from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models import db, Pond, FeedLog, DiseaseHistory, WaterQuality, GrowthHistory, HarvestRecord


dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
@login_required
def dashboard():
    user = current_user
    ponds = Pond.query.filter_by(user_id=user.id).all()

    total_biomass = 0.0
    for pond in ponds:
        latest_growth = GrowthHistory.query.filter_by(user_id=user.id, pond_id=pond.id).order_by(GrowthHistory.record_date.desc()).first()
        if latest_growth:
            total_biomass += latest_growth.biomass_kg

    today = datetime.utcnow().date()
    today_feed = FeedLog.query.filter_by(user_id=user.id).filter(FeedLog.date == today).all()
    todays_feed = sum(log.daily_feed_requirement for log in today_feed)
    feed_per_session = sum(log.feed_per_session for log in today_feed) / len(today_feed) if today_feed else 0.0
    active_ponds = sum(1 for pond in ponds if pond.status.lower() == "active")
    disease_detections = DiseaseHistory.query.filter_by(user_id=user.id).count()
    latest_water = WaterQuality.query.filter_by(user_id=user.id).order_by(WaterQuality.recorded_at.desc()).first()
    water_status = latest_water.status if latest_water else "No data"

    labels = []
    feed_series = []
    growth_series = []
    for i in range(6, -1, -1):
        day = (datetime.utcnow().date() - timedelta(days=i))
        labels.append(day.strftime("%b %d"))
        day_feed = FeedLog.query.filter_by(user_id=user.id).filter(FeedLog.date == day).all()
        feed_series.append(round(sum(log.daily_feed_requirement for log in day_feed), 2))
        day_growth = GrowthHistory.query.filter_by(user_id=user.id).filter(GrowthHistory.record_date == day).all()
        growth_series.append(round(sum(log.biomass_kg for log in day_growth), 2))

    status_counts = {"Excellent": 0, "Good": 0, "Warning": 0, "Critical": 0}
    for record in WaterQuality.query.filter_by(user_id=user.id).all():
        status_counts[record.status] = status_counts.get(record.status, 0) + 1

    recent_activities = []
    for log in FeedLog.query.filter_by(user_id=user.id).order_by(FeedLog.created_at.desc()).limit(5).all():
        recent_activities.append(("Feed", f"{log.daily_feed_requirement:.2f} kg recorded for {log.notes or 'a pond'}"))
    for disease in DiseaseHistory.query.filter_by(user_id=user.id).order_by(DiseaseHistory.created_at.desc()).limit(5).all():
        recent_activities.append(("Disease", f"{disease.disease_name} detected with {disease.confidence:.0%} confidence"))
    for quality in WaterQuality.query.filter_by(user_id=user.id).order_by(WaterQuality.recorded_at.desc()).limit(5).all():
        recent_activities.append(("Water", f"Water quality noted as {quality.status}"))

    recent_activities = sorted(recent_activities, key=lambda item: item[1], reverse=True)[:8]

    return render_template(
        "dashboard.html",
        ponds=ponds,
        total_biomass=round(total_biomass, 2),
        todays_feed=round(todays_feed, 2),
        feed_per_session=round(feed_per_session, 2),
        active_ponds=active_ponds,
        disease_detections=disease_detections,
        water_status=water_status,
        recent_activities=recent_activities,
        labels=labels,
        feed_series=feed_series,
        growth_series=growth_series,
        status_labels=list(status_counts.keys()),
        status_counts=list(status_counts.values()),
    )
